import discord
import random
import asyncio
import sys
from discord.ext import commands

intents = discord.Intents.default()
intents.messages = True
intents.guilds = True
intents.reactions = True

client = commands.Bot(command_prefix=".", intents=intents)

@client.event
async def on_ready():
    print("Made by Tblyakee for questions join my server https://discord.gg/ZN2YkHk353")
    print(f"We have logged in as {client.user.name}")

    # Check if the bot is in any servers
    for guild in client.guilds:
        print(f"Bot is connected to server: {guild.name} (ID: {guild.id})")

    # Main loop
    while True:
        # Ask for the user's choice and the server to operate on
        await ask_for_choice()

        # Ask if the user wants to return to the main menu or close the application
        return_to_menu = input("Do you want to return to the main menu? (yes/no): ").lower()
        if return_to_menu != 'yes':
            sys.exit()  # Exit the program if the user enters "no"

async def ask_for_choice():
    try:
        await client.wait_until_ready()

        # Ask the user for the server to operate on
        print("Select a server:")
        for i, guild in enumerate(client.guilds, start=1):
            print(f"{i}. {guild.name}")

        server_index = int(input("Enter the number corresponding to the server: "))
        selected_server = client.guilds[server_index - 1]

        # Ask the user for their choice in the terminal
        print("1. Send message\n2. Send emojis\n3. Nuke (create channels)\n4. Delete all channels\n5. Send message everywhere")
        choice = int(input("Enter your choice (1 to 5): "))

        if choice == 1:
            message_content = input("What message do you want to send?: ")
            times = int(input("How many times do you want to send the message?: "))

            tasks = []
            for channel in selected_server.channels:
                if isinstance(channel, discord.TextChannel):
                    for _ in range(times):
                        tasks.append(send_message(channel, message_content))

            await asyncio.gather(*tasks)
            print(f"Message '{message_content}' sent {times} times to all channels in {selected_server.name}.")

        elif choice == 2:
            num_emojis = int(input("How many emojis do you want to send?: "))
            print(f"Sending {num_emojis} random emojis to all channels in {selected_server.name}...")

            tasks = []
            for channel in selected_server.channels:
                if isinstance(channel, discord.TextChannel):
                    emojis = [":smile:", ":heart:", ":star:", ":fire:", ":thumbsup:"]
                    for _ in range(num_emojis):
                        random_emoji = random.choice(emojis)
                        tasks.append(send_message(channel, random_emoji))

            await asyncio.gather(*tasks)
            print(f"{num_emojis} random emojis sent to all channels in {selected_server.name}.")

        elif choice == 3:
            channel_name = input("Enter the name of the channel to be created: ")
            num_channels = int(input("How many channels do you want to create?: "))

            for _ in range(num_channels):
                await selected_server.create_text_channel(channel_name)

            print(f"{num_channels} channels named '{channel_name}' created in {selected_server.name}.")

        elif choice == 4:
            # Deleting all channels in the server
            for channel in selected_server.channels:
                await channel.delete()

            print(f"All channels deleted in {selected_server.name}.")

        elif choice == 5:
            message_content = input("What message do you want to send everywhere?: ")
            num_messages = int(input("How many messages do you want to send?: "))

            tasks = []
            for guild in client.guilds:
                for channel in guild.channels:
                    if isinstance(channel, discord.TextChannel):
                        for _ in range(num_messages):
                            tasks.append(send_message(channel, message_content))

            await asyncio.gather(*tasks)
            print(f"{num_messages} messages '{message_content}' sent to all channels in every server.")

        else:
            print("Invalid choice.")
    except (ValueError, IndexError):
        print("Invalid input. Please enter a valid number.")

async def send_message(channel, content):
    try:
        await channel.send(content)
        await asyncio.sleep(1)  # Add a delay of 1 second
    except Exception as e:
        print(f"Failed to send message to channel {channel.id} in {channel.guild.name}: {e}")

# Start the bot after obtaining the token
token = input("Please enter your bot token: ")
client.run(token)
